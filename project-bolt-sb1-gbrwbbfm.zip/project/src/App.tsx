import React, { useState } from 'react';
import { Header } from './components/Header';
import { MobileMenu } from './components/MobileMenu';
import { HomePage } from './pages/HomePage';
import { PreviewPage } from './pages/PreviewPage';
import { AboutPage } from './pages/AboutPage';

type Page = 'home' | 'preview' | 'about';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async (newPrompt: string) => {
    setPrompt(newPrompt);
    setIsLoading(true);
    setImageUrl('');

    const sketchPrompt = `Create a professional, high-detail black-and-white sketch. If the prompt specifically mentions color, include it; otherwise, render only a precise stroked diagram using clean, thin vector-style lines with a 2px stroke width and high visual clarity. The drawing should follow strict anatomical or mechanical accuracy, depending on the subject. Add a bold, elegant signature that says "Diagra" in the bottom-right corner, using a 50px Monospace or Sans-serif font with high contrast.`;

    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(sketchPrompt)}?nologo=true`;


    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      
      img.onload = () => {
        setImageUrl(url);
        setIsLoading(false);
      };

      img.onerror = () => {
        setIsLoading(false);
        setImageUrl('');
      };

      img.src = url;
    } catch (error) {
      setIsLoading(false);
      setImageUrl('');
    }
  };

  const handleSaveImage = () => {
    if (!imageUrl) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) return;

      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      ctx.drawImage(img, 0, 0);

      canvas.toBlob((blob) => {
        if (!blob) return;
        
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        const filename = prompt 
          ? `diagram-${prompt.replace(/[^a-zA-Z0-9]/g, '-')}.png` 
          : 'diagram-sketch.png';

        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 'image/png');
    };

    img.src = imageUrl;
  };

  const handleRegenerate = () => {
    if (prompt) {
      handleGenerate(prompt);
    }
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <HomePage
            onGenerate={handleGenerate}
            onNavigateToPreview={() => setCurrentPage('preview')}
            isLoading={isLoading}
          />
        );
      case 'preview':
        return (
          <PreviewPage
            imageUrl={imageUrl}
            prompt={prompt}
            isLoading={isLoading}
            onRegenerate={handleRegenerate}
            onSave={handleSaveImage}
            onBack={() => setCurrentPage('home')}
          />
        );
      case 'about':
        return <AboutPage />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onMenuToggle={() => setIsMobileMenuOpen(true)}
      />
      
      <MobileMenu
        isOpen={isMobileMenuOpen}
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onClose={() => setIsMobileMenuOpen(false)}
      />

      <main>
        {renderCurrentPage()}
      </main>
    </div>
  );
}

export default App;
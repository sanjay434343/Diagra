import React, { useState } from 'react';
import { Sparkles, Lightbulb, Zap, ArrowRight } from 'lucide-react';
import { MaterialCard } from '../components/MaterialCard';
import { FloatingActionButton } from '../components/FloatingActionButton';

interface HomePageProps {
  onGenerate: (prompt: string) => void;
  onNavigateToPreview: () => void;
  isLoading: boolean;
}

export const HomePage: React.FC<HomePageProps> = ({ onGenerate, onNavigateToPreview, isLoading }) => {
  const [prompt, setPrompt] = useState('');

  const handleGenerate = () => {
    if (prompt.trim()) {
      onGenerate(prompt.trim());
      onNavigateToPreview();
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleGenerate();
    }
  };

  const examplePrompts = [
    'Database architecture with microservices',
    'User authentication flow diagram',
    'Network topology with load balancers',
    'API gateway architecture',
    'Cloud infrastructure diagram',
    'Data pipeline workflow'
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-6">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Create Technical Diagrams
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Transform your ideas into professional technical diagrams using AI. 
            Simply describe what you want and watch it come to life.
          </p>
        </div>

        {/* Main Input Card */}
        <MaterialCard elevated className="mb-8">
          <div className="p-6">
            <div className="flex items-center mb-4">
              <Zap className="w-5 h-5 text-blue-500 mr-2" />
              <h2 className="text-lg font-semibold text-gray-900">Describe Your Diagram</h2>
            </div>
            
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Describe the technical diagram you want to create..."
              className="w-full h-32 p-4 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            />
            
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-gray-500">
                Press Ctrl + Enter to generate quickly
              </p>
              <button
                onClick={handleGenerate}
                disabled={!prompt.trim() || isLoading}
                className="inline-flex items-center px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors duration-200"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    Generate Diagram
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </button>
            </div>
          </div>
        </MaterialCard>

        {/* Example Prompts */}
        <MaterialCard className="mb-8">
          <div className="p-6">
            <div className="flex items-center mb-4">
              <Lightbulb className="w-5 h-5 text-yellow-500 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Example Prompts</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {examplePrompts.map((example, index) => (
                <button
                  key={index}
                  onClick={() => setPrompt(example)}
                  className="text-left p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200 text-sm text-gray-700"
                >
                  {example}
                </button>
              ))}
            </div>
          </div>
        </MaterialCard>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MaterialCard>
            <div className="p-6 text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-6 h-6 text-blue-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">AI-Powered</h3>
              <p className="text-gray-600 text-sm">
                Advanced AI understands your technical requirements and creates accurate diagrams
              </p>
            </div>
          </MaterialCard>

          <MaterialCard>
            <div className="p-6 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-green-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Lightning Fast</h3>
              <p className="text-gray-600 text-sm">
                Generate professional diagrams in seconds, not hours of manual drawing
              </p>
            </div>
          </MaterialCard>

          <MaterialCard>
            <div className="p-6 text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <ArrowRight className="w-6 h-6 text-purple-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Export Ready</h3>
              <p className="text-gray-600 text-sm">
                Download high-quality images ready for presentations and documentation
              </p>
            </div>
          </MaterialCard>
        </div>
      </div>

      <FloatingActionButton 
        onClick={handleGenerate}
        disabled={!prompt.trim() || isLoading}
      />
    </div>
  );
};
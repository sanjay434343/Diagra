import React from 'react';
import { Sparkles, Zap, Shield, Heart, Github, Mail, Globe } from 'lucide-react';
import { MaterialCard } from '../components/MaterialCard';

export const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-6">
            <Sparkles className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About DiagramAI</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Empowering developers and architects to create professional technical diagrams 
            with the power of artificial intelligence.
          </p>
        </div>

        {/* Mission Statement */}
        <MaterialCard elevated className="mb-8">
          <div className="p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              We believe that creating technical diagrams shouldn't be a time-consuming process. 
              DiagramAI leverages cutting-edge AI technology to transform your ideas into 
              professional, accurate diagrams in seconds, allowing you to focus on what matters most - 
              building great software.
            </p>
          </div>
        </MaterialCard>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <MaterialCard>
            <div className="p-6 text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-6 h-6 text-blue-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">AI-Powered Generation</h3>
              <p className="text-gray-600 text-sm">
                Advanced machine learning models understand technical concepts and create accurate visual representations
              </p>
            </div>
          </MaterialCard>

          <MaterialCard>
            <div className="p-6 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-green-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Lightning Fast</h3>
              <p className="text-gray-600 text-sm">
                Generate complex technical diagrams in seconds, not hours of manual drawing and editing
              </p>
            </div>
          </MaterialCard>

          <MaterialCard>
            <div className="p-6 text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-purple-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Privacy First</h3>
              <p className="text-gray-600 text-sm">
                Your diagrams and prompts are processed securely with no data retention or sharing
              </p>
            </div>
          </MaterialCard>
        </div>

        {/* Technology Stack */}
        <MaterialCard className="mb-8">
          <div className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Built With Modern Technology</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-50 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl font-bold text-blue-500">R</span>
                </div>
                <h4 className="font-semibold text-gray-900">React</h4>
                <p className="text-sm text-gray-600">Modern UI Framework</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-50 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl font-bold text-blue-600">TS</span>
                </div>
                <h4 className="font-semibold text-gray-900">TypeScript</h4>
                <p className="text-sm text-gray-600">Type Safety</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-cyan-50 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl font-bold text-cyan-500">TW</span>
                </div>
                <h4 className="font-semibold text-gray-900">Tailwind CSS</h4>
                <p className="text-sm text-gray-600">Styling Framework</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-50 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl font-bold text-purple-500">AI</span>
                </div>
                <h4 className="font-semibold text-gray-900">AI Models</h4>
                <p className="text-sm text-gray-600">Image Generation</p>
              </div>
            </div>
          </div>
        </MaterialCard>

        {/* Use Cases */}
        <MaterialCard className="mb-8">
          <div className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Perfect For</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Software Architects</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• System architecture diagrams</li>
                  <li>• Microservices topology</li>
                  <li>• Database schemas</li>
                  <li>• API flow diagrams</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">DevOps Engineers</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• Infrastructure diagrams</li>
                  <li>• CI/CD pipelines</li>
                  <li>• Network topologies</li>
                  <li>• Deployment workflows</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Product Managers</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• User journey flows</li>
                  <li>• Feature workflows</li>
                  <li>• Process diagrams</li>
                  <li>• System overviews</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Developers</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• Code architecture</li>
                  <li>• Data flow diagrams</li>
                  <li>• Integration patterns</li>
                  <li>• Technical documentation</li>
                </ul>
              </div>
            </div>
          </div>
        </MaterialCard>

        {/* Contact Section */}
        <MaterialCard>
          <div className="p-8 text-center">
            <div className="flex items-center justify-center mb-4">
              <Heart className="w-6 h-6 text-red-500 mr-2" />
              <h2 className="text-2xl font-bold text-gray-900">Get In Touch</h2>
            </div>
            <p className="text-gray-600 mb-6">
              Have questions, suggestions, or feedback? We'd love to hear from you!
            </p>
            <div className="flex justify-center space-x-6">
              <a
                href="mailto:hello@diagramai.com"
                className="inline-flex items-center px-4 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors duration-200"
              >
                <Mail className="w-4 h-4 mr-2" />
                Email Us
              </a>
              <a
                href="https://github.com/diagramai"
                className="inline-flex items-center px-4 py-2 bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors duration-200"
              >
                <Github className="w-4 h-4 mr-2" />
                GitHub
              </a>
              <a
                href="https://diagramai.com"
                className="inline-flex items-center px-4 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors duration-200"
              >
                <Globe className="w-4 h-4 mr-2" />
                Website
              </a>
            </div>
          </div>
        </MaterialCard>
      </div>
    </div>
  );
};
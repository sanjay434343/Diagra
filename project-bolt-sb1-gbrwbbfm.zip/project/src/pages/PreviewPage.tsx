import React from 'react';
import { Download, RefreshCw, ArrowLeft, Image as ImageIcon } from 'lucide-react';
import { MaterialCard } from '../components/MaterialCard';

interface PreviewPageProps {
  imageUrl: string;
  prompt: string;
  isLoading: boolean;
  onRegenerate: () => void;
  onSave: () => void;
  onBack: () => void;
}

export const PreviewPage: React.FC<PreviewPageProps> = ({
  imageUrl,
  prompt,
  isLoading,
  onRegenerate,
  onSave,
  onBack
}) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <button
              onClick={onBack}
              className="inline-flex items-center px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors duration-200 mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Create
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Diagram Preview</h1>
              {prompt && (
                <p className="text-gray-600 mt-1">"{prompt}"</p>
              )}
            </div>
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={onRegenerate}
              disabled={isLoading}
              className="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Regenerate
            </button>
            
            {imageUrl && !isLoading && (
              <button
                onClick={onSave}
                className="inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </button>
            )}
          </div>
        </div>

        {/* Preview Card */}
        <MaterialCard elevated>
          <div className="p-8">
            <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
              {isLoading ? (
                <div className="text-center">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-500 rounded-full animate-spin mx-auto"></div>
                    <div className="absolute inset-0 w-16 h-16 border-4 border-transparent border-r-purple-500 rounded-full animate-spin mx-auto" style={{ animationDelay: '0.15s' }}></div>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Creating Your Diagram</h3>
                  <p className="text-gray-600">This may take a few moments...</p>
                  <div className="flex justify-center mt-4 space-x-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-pink-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              ) : imageUrl ? (
                <img
                  src={imageUrl}
                  alt="Generated diagram"
                  className="max-w-full max-h-full object-contain rounded-lg shadow-sm"
                />
              ) : (
                <div className="text-center text-gray-500">
                  <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-semibold mb-2">No Diagram Yet</h3>
                  <p>Go back to create your first diagram</p>
                </div>
              )}
            </div>
          </div>
        </MaterialCard>

        {/* Info Cards */}
        {imageUrl && !isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <MaterialCard>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Diagram Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Format:</span>
                    <span className="text-gray-900">PNG Image</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Quality:</span>
                    <span className="text-gray-900">High Resolution</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className="text-green-600 font-medium">Ready to Download</span>
                  </div>
                </div>
              </div>
            </MaterialCard>

            <MaterialCard>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Quick Actions</h3>
                <div className="space-y-3">
                  <button
                    onClick={onSave}
                    className="w-full flex items-center justify-center px-4 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors duration-200"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Image
                  </button>
                  <button
                    onClick={onRegenerate}
                    className="w-full flex items-center justify-center px-4 py-2 bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors duration-200"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Generate New Version
                  </button>
                </div>
              </div>
            </MaterialCard>
          </div>
        )}
      </div>
    </div>
  );
};
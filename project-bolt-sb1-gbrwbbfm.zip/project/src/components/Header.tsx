import React from 'react';
import { Menu, Info, Home, Image } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onMenuToggle: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate, onMenuToggle }) => {
  return (
    <header className="bg-white shadow-md border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <button
              onClick={onMenuToggle}
              className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 md:hidden"
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="flex-shrink-0 flex items-center ml-2 md:ml-0">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Image className="w-5 h-5 text-white" />
              </div>
              <h1 className="ml-3 text-xl font-semibold text-gray-900">DiagramAI</h1>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => onNavigate('home')}
              className={`inline-flex items-center px-1 pt-1 text-sm font-medium border-b-2 transition-colors ${
                currentPage === 'home'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Home className="w-4 h-4 mr-2" />
              Create
            </button>
            <button
              onClick={() => onNavigate('preview')}
              className={`inline-flex items-center px-1 pt-1 text-sm font-medium border-b-2 transition-colors ${
                currentPage === 'preview'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Image className="w-4 h-4 mr-2" />
              Preview
            </button>
            <button
              onClick={() => onNavigate('about')}
              className={`inline-flex items-center px-1 pt-1 text-sm font-medium border-b-2 transition-colors ${
                currentPage === 'about'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Info className="w-4 h-4 mr-2" />
              About
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
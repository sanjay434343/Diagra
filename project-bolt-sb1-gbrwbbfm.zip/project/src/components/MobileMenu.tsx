import React from 'react';
import { Home, Image, Info, X } from 'lucide-react';

interface MobileMenuProps {
  isOpen: boolean;
  currentPage: string;
  onNavigate: (page: string) => void;
  onClose: () => void;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, currentPage, onNavigate, onClose }) => {
  if (!isOpen) return null;

  const handleNavigate = (page: string) => {
    onNavigate(page);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      <div className="fixed inset-0 bg-black bg-opacity-25" onClick={onClose} />
      <div className="fixed top-0 left-0 bottom-0 w-64 bg-white shadow-xl">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Image className="w-5 h-5 text-white" />
            </div>
            <h1 className="ml-3 text-xl font-semibold text-gray-900">DiagramAI</h1>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <nav className="mt-4">
          <button
            onClick={() => handleNavigate('home')}
            className={`w-full flex items-center px-4 py-3 text-left text-base font-medium transition-colors ${
              currentPage === 'home'
                ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-500'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <Home className="w-5 h-5 mr-3" />
            Create Diagram
          </button>
          <button
            onClick={() => handleNavigate('preview')}
            className={`w-full flex items-center px-4 py-3 text-left text-base font-medium transition-colors ${
              currentPage === 'preview'
                ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-500'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <Image className="w-5 h-5 mr-3" />
            Preview
          </button>
          <button
            onClick={() => handleNavigate('about')}
            className={`w-full flex items-center px-4 py-3 text-left text-base font-medium transition-colors ${
              currentPage === 'about'
                ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-500'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <Info className="w-5 h-5 mr-3" />
            About
          </button>
        </nav>
      </div>
    </div>
  );
};
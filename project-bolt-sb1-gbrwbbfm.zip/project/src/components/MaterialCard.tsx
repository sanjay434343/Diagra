import React from 'react';

interface MaterialCardProps {
  children: React.ReactNode;
  className?: string;
  elevated?: boolean;
}

export const MaterialCard: React.FC<MaterialCardProps> = ({ 
  children, 
  className = '', 
  elevated = false 
}) => {
  return (
    <div className={`
      bg-white rounded-lg border border-gray-200 transition-shadow duration-200
      ${elevated ? 'shadow-lg hover:shadow-xl' : 'shadow-sm hover:shadow-md'}
      ${className}
    `}>
      {children}
    </div>
  );
};